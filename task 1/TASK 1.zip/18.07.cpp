﻿
#include <iostream>
#include <cassert>
#include <string>
#include <sstream>
#include <map>
using namespace std;

class Contact {
private:
	int _id;
	string _name;
	string _surname;
	string _username;
public:
	Contact() {
		_id++;
		_name = nullptr;
		_surname = nullptr;
		_username = nullptr;

	}

	Contact(string name, string surname, string username) {
		_name = name;
		_surname = surname;
		_username = username;
	}

	void setName(string name) {
		if (_name.length() < 3) {
			throw invalid_argument("Minimum 4 character!");
		}
		else
			_name = name;
	}

	void setSurname(string surname) {
		if (_surname.length() < 3) {
			throw invalid_argument("Minimum 4 character!");
		}
		else
			_surname = surname;
	}

	void setUsername(string username) {
		if (_username.length() < 3) {
			throw invalid_argument("Minimum 4 character!");
		}
		else
			_username = username;
	}

	string getName() { return this->_name; }
	string getSurname() { return this->_surname; }
	string getUsername() { return this->_username; }

	void show() {
		cout << "===> CONTACT LIST <===" << "\n\n";
		cout << "Id : " << _id << endl;
		cout << "Username : " << _username << endl;
		cout << "Name : " << _name << endl;
		cout << "Surname : " << _surname << endl;
		cout << "---------------------------------" << "\n\n";

	}


};


class DataBase : public Contact
{
	int person_count = 0;
	Contact** people;
public:
	//AddContact() 
	void AddContact(const Contact&person) {
		Contact** newusers = new Contact * [person_count + 1];
		for (size_t i = 0; i < person_count; i++)
			newusers[i] = people[i];
		newusers[person_count] = new Contact(person);
		delete[] people;
		people = newusers;
		person_count++;
	}
	//DeleteByName() 
	void DeleteByName(const string& name) {
		size_t i;
		for (i = 0; i < person_count; i++) {
			if (people[i]->getName() == name) {
				delete people[i];
				break;
			}
		}
		if (i == person_count) {
			throw runtime_error("User not found.");
		}
		for (size_t j = i; j < person_count - 1; j++) {
			people[j] = people[j + 1];
		}
		person_count--;
	}
	//SearchByName()
	void SearchByName(const string & name) {
		size_t i;
		for (i = 0; i < person_count; i++) {
			if (people[i]->getName() == name) {
				delete people[i];
				break;
			}
	}
}